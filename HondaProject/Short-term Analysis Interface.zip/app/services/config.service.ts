import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  constructor(private http: HttpClient) { }

  configUrl = 'assets/data.txt';

  getConfig() {
    return this.http.get(this.configUrl,{responseType: "text"});
  }
}
