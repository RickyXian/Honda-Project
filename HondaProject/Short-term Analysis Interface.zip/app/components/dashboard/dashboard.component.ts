import { Component, OnInit } from '@angular/core';
import * as ChartAnnotation from 'chartjs-plugin-annotation';
import {Chart,ChartOptions}from 'chart.js'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  canvas:any;
  ctx:any;
//   public ChartOptions:{
//     scales: {
//       yAxes: [{

//           ticks: {
//               min: 0, 
//               max:1   // minimum will be 0, unless there is a lower value.
//           }
//       }]
//   },
//   annotation:{
//     annotations:[
//       {          
//         type:'box',
//         drawTime:'beforeDatasetsDraw',
//         id:'a-box-1',
//         xScaleID:'x-axis-0',
//         yScaleID:'y-axis-0',
//         xMin:2,
//         xMax:3,

//         borderColor:'red',
//         borderWidth:2,
//         backgroundColor:'green',
//       }]


//   }

// }

  
//   public ChartLabels = ['1', '2', '3', '4', '5', '6', '7'];
//   public ChartType = 'scatter';
//   public ChartLegend = false;
//   public ChartData = [
//     {data: [{
//       x:1,
//       y:0.5
//     },
//     {
//       x:2,
//       y:0.2
//     },
//     {
//       x:3,
//       y:0.3
//     }],
//     label: 'DRIP',
//     showLine:false,
//     pointStyle:'circle',
//     radius: 5
//     }
//   ];




  


  constructor() { 
  }
  ngOnInit(): void {
    this.canvas = document.getElementById('myChart');
    this.ctx = this.canvas.getContext('2d');
    let myChart = new Chart(this.ctx, {
      type: 'line',
      data: {
          labels:[1,2,3,4,5,6],
          datasets: [{
              label: '# of Votes',
              data: [1,2,3,4,5,6],
              
          }]
      },
      options: {
        responsive: false,
        scales: {
          yAxes:[{
            ticks: {
              min: 2,
              max: 5
          }
          }]   
        },
        annotation:{
          annotations:[
            {          
              type:'box',
              drawTime:'beforeDatasetsDraw',
              id:'a-box-1',
              xScaleID:'x-axis-0',
              yScaleID:'y-axis-0',
              yMin:2,
              yMax:4,
    
              borderColor:'red',
              borderWidth:2,
              backgroundColor:'green',
            }]


        }
 
    } as ChartOptions,
      plugins:[ChartAnnotation]
      
    });

}
}
